SNIPER AI — responsive professional version

Single-file static site. Responsive desktop/tablet/mobile layout, mobile menu, AI chat, traffic counters, partner links and subtle small snow animation.
