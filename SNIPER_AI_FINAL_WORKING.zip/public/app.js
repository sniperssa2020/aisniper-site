const $=s=>document.querySelector(s);
const toast=t=>{const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2600)};
for(let i=0;i<75;i++){const f=document.createElement("span");f.className="flake";f.textContent="•";f.style.left=Math.random()*100+"%";f.style.animationDuration=(8+Math.random()*14)+"s";f.style.animationDelay=(-Math.random()*15)+"s";f.style.fontSize=(4+Math.random()*7)+"px";$("#snow").appendChild(f)}
let views=+(localStorage.sniperViews||0)+1;localStorage.sniperViews=views;$("#views").textContent=views;$("#traffic").textContent=" • Ваш просмотр № "+views;

const pg=$("#partnersGrid"); window.SNIPER_PARTNERS.forEach(p=>{pg.insertAdjacentHTML("beforeend",`<article class="partner"><h3>${p.name}</h3><p>Предложение / cashback: ${p.cashback}</p><a href="${p.url}" target="_blank" rel="noopener sponsored">Перейти →</a></article>`)});

$("#photoInput").onchange=e=>{const file=e.target.files[0];if(!file)return;const url=URL.createObjectURL(file);$("#photoPreview").innerHTML=`<img src="${url}" alt="Предпросмотр">`};
$("#restoreBtn").onclick=()=>{const f=$("#photoInput").files[0];if(!f){toast("Сначала выберите фотографию");return}const text=encodeURIComponent("Здравствуйте! Хочу заказать реставрацию фотографии. Фото готов отправить.");window.open("https://wa.me/77474701201?text="+text,"_blank")};

async function api(path,body){const r=await fetch(path,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)});if(!r.ok)throw Error("API "+r.status);return r.json()}
$("#translateBtn").onclick=async()=>{const text=$("#trText").value.trim();if(!text)return;$("#trOut").value="Перевожу…";try{const r=await api("/api/translate",{text,from:$("#from").value,to:$("#to").value});$("#trOut").value=r.text}catch(e){$("#trOut").value="Для полноценного AI-перевода подключите GEMINI_API_KEY в Cloudflare Worker.";toast("AI-перевод требует секрет API")}};
const addMsg=(t,c)=>{const d=document.createElement("div");d.className="msg "+c;d.textContent=t;$("#messages").appendChild(d);$("#messages").scrollTop=99999};
async function ask(t){addMsg(t,"user");try{const r=await api("/api/chat",{message:t,language:"ru"});addMsg(r.text||"Не удалось получить ответ.","ai")}catch(e){addMsg("Сейчас я работаю в демо-режиме. Для настоящего AI-чата добавьте GEMINI_API_KEY в секреты Worker. Я могу помочь с услугами, реставрацией фото, переводами и подбором товаров.","ai")}}
$("#chatForm").onsubmit=e=>{e.preventDefault();const v=$("#chatInput").value.trim();if(v){$("#chatInput").value="";ask(v)}};document.querySelectorAll(".quick button").forEach(b=>b.onclick=()=>ask(b.textContent));
document.querySelectorAll("[data-lang]").forEach(b=>b.onclick=()=>toast("Интерфейс подготовлен для RU / KZ / EN; перевод сообщений выполняет AI после подключения ключа."));
$("#menuBtn").onclick=()=>{const n=document.querySelector("nav");n.style.display=n.style.display==="flex"?"none":"flex";n.style.position="absolute";n.style.top="64px";n.style.left="0";n.style.right="0";n.style.padding="18px";n.style.background="#060c19";n.style.flexDirection="column"};