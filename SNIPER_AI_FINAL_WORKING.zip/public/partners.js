window.SNIPER_PARTNERS = [
 {name:"AliExpress", cashback:"до 69%", url:"https://www.aliexpress.com/"},
 {name:"Banggood", cashback:"до 8.5%", url:"https://www.banggood.com/"},
 {name:"М.Видео", cashback:"до 1.7%", url:"https://www.mvideo.ru/"},
 {name:"Ситилинк", cashback:"до 1.6%", url:"https://www.citilink.ru/"},
 {name:"iHerb", cashback:"до 5.5%", url:"https://www.iherb.com/"},
 {name:"Л'Этуаль", cashback:"до 5%", url:"https://www.letu.ru/"},
 {name:"Яндекс Маркет", cashback:"до 2.7%", url:"https://market.yandex.ru/"},
 {name:"OZON", cashback:"до 4.7%", url:"https://www.ozon.ru/"},
 {name:"Avito", cashback:"до 1.4%", url:"https://www.avito.ru/"}
];