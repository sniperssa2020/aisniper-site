const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"GET,POST,OPTIONS"};
function json(o,s=200){return new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json;charset=UTF-8",...cors}})}
async function gemini(env,prompt){if(!env.GEMINI_API_KEY)return null;const url=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${env.GEMINI_API_KEY}`;const r=await fetch(url,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})});if(!r.ok)throw Error("Gemini "+r.status);const d=await r.json();return d?.candidates?.[0]?.content?.parts?.[0]?.text||null}
const fallback="Здравствуйте! Я AI-Помощник Сергея Санникова. Могу помочь с услугами, подбором товаров, переводом, реставрацией фотографий и цифровыми решениями. Для настоящего AI-ответа добавьте GEMINI_API_KEY в секреты Worker.";
export default {async fetch(req,env){if(req.method==="OPTIONS")return new Response("",{headers:cors});const u=new URL(req.url);
if(req.method==="GET" && u.pathname==="/api/health")return json({ok:true,ai:!!env.GEMINI_API_KEY});
if(req.method!=="POST")return fetch(req);
let body={};try{body=await req.json()}catch{return json({error:"bad json"},400)}
try{
 if(u.pathname==="/api/chat"){const prompt=`Ты — AI-Помощник Сергея Санникова на сайте SNIPER AI. Отвечай по-русски, кратко и полезно. Услуги: реставрация старых фотографий, переводы RU/KZ/EN, AI-консультации, подбор товаров, цифровые решения. Если вопрос о заказе — предложи WhatsApp +77474701201. Пользователь: ${body.message}`;return json({text:(await gemini(env,prompt))||fallback})}
 if(u.pathname==="/api/translate"){const prompt=`Переведи текст с ${body.from} на ${body.to}. Верни только перевод, без комментариев. Текст: ${body.text}`;return json({text:(await gemini(env,prompt))||"AI-перевод недоступен без GEMINI_API_KEY."})}
 return json({error:"not found"},404)
}catch(e){return json({error:e.message},500)}}};