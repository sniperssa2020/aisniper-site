const PHONE = "77474701201";
const EMAIL = "sniperssa282896@gmail.com";
const TELEGRAM = "https://t.me/sniperssaai";
const WHATSAPP = "https://wa.me/77474701201";

/*
  SNIPER AI — improved single-file Worker.

  What is improved:
  - Short mobile-friendly AI greeting.
  - Better intent detection: "пылесос" is treated as a product query.
  - Correct contact handling (phone is checked before product intent).
  - Telegram, WhatsApp, phone and email links included.
  - Product-search UI is prepared for future affiliate APIs.
  - Private admin/statistics foundation is included, but real purchase/commission
    data requires the relevant affiliate network APIs/postbacks.
  - Visitor events are kept server-side in memory only in this simple version.
    For permanent analytics, connect a database such as Cloudflare D1/KV later.
*/

function aiReply(message) {
  const q = (message || "").toLowerCase().trim();

  // Contacts first, so "телефон Сергея" means contact phone, not a phone product.
  if (
    q.includes("телефон сергея") ||
    q.includes("номер сергея") ||
    q === "телефон" ||
    q.includes("позвон")
  ) {
    return "📞 Телефон Сергея: +7 747 470-12-01";
  }

  if (q.includes("whatsapp") || q.includes("ватсап")) {
    return "💬 WhatsApp: +7 747 470-12-01";
  }

  if (q.includes("telegram") || q.includes("телеграм")) {
    return "✈️ Telegram: @sniperssaai";
  }

  if (
    q.includes("email") ||
    q.includes("почт") ||
    q.includes("емейл") ||
    q.includes("электронная почта")
  ) {
    return "✉️ Email: sniperssa282896@gmail.com";
  }

  if (q.includes("привет") || q.includes("здравств") || q === "hi" || q === "hello") {
    return "Здравствуйте! 👋 Я AI-помощник SNIPER AI. Чем могу помочь?";
  }

  if (
    q.includes("кто ты") ||
    q.includes("о тебе") ||
    q.includes("кто такой сергей") ||
    q.includes("обо мне") ||
    q.includes("sniper ai")
  ) {
    return "SNIPER AI — цифровое направление Сергея Санникова с использованием современных AI-технологий: сайты, цифровые продукты, обработка фото, переводы, AI-сервисы и поиск полезных предложений.";
  }

  // Product intent. Includes generic words and many common product types.
  const productWords = [
    "товар", "купить", "пылесос", "телефон", "смартфон", "айфон", "iphone",
    "ноутбук", "компьютер", "планшет", "телевизор", "телевизор", "наушник",
    "часы", "смарт-часы", "холодильник", "стирал", "робот", "монитор",
    "клавиатур", "мышь", "камера", "фотоаппарат", "принтер", "дрель",
    "перфоратор", "велосипед", "самокат", "куртк", "обув", "кроссовк",
    "одежд", "космет", "мебел", "диван", "кресл", "авто", "автомобил"
  ];

  if (productWords.some(word => q.includes(word))) {
    return "🛒 Понял запрос. Сейчас поиск товаров в этой версии подготовлен как демонстрация. Следующий шаг — подключить реальные каталоги магазинов и ваши партнёрские ссылки, чтобы для каждого магазина использовалась ваша affiliate-ссылка.";
  }

  if (
    q.includes("фото") ||
    q.includes("фотограф") ||
    q.includes("реставрац") ||
    q.includes("черно-бел")
  ) {
    return "📸 SNIPER AI может помочь с восстановлением старых фотографий, улучшением качества и раскрашиванием чёрно-белых снимков.";
  }

  if (q.includes("перевод") || q.includes("язык")) {
    return "🌎 Можно заказать перевод текста. Напишите, какой текст и с какого языка на какой нужен перевод.";
  }

  if (
    q.includes("искусственный интеллект") ||
    q === "ии" ||
    q.includes("нейросет") ||
    q === "ai"
  ) {
    return "🤖 AI — основа проекта SNIPER AI. Здесь постепенно будут появляться AI-инструменты, сервисы и полезные решения.";
  }

  return "Понял вас. Попробуйте написать, например: «найди пылесос до 100 000 ₸», «расскажи про SNIPER AI», «как связаться с Сергеем» или «какие есть AI-сервисы».";
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
      "Cache-Control": "no-store"
    }
  });
}

const HTML = `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SNIPER AI</title>
<meta name="description" content="SNIPER AI — AI-помощник, цифровые продукты и полезные сервисы.">
<style>
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{
  margin:0;font-family:Arial,Helvetica,sans-serif;color:#fff;min-height:100vh;
  background:
    linear-gradient(rgba(4,15,35,.76),rgba(4,12,28,.93)),
    radial-gradient(circle at top,#214c78,#071426 70%);
}
.container{position:relative;z-index:3;width:92%;max-width:1050px;margin:auto}
header{
  position:sticky;top:0;z-index:20;padding:15px 0;
  background:rgba(2,10,23,.76);backdrop-filter:blur(15px);
  border-bottom:1px solid rgba(255,255,255,.1)
}
.nav{display:flex;justify-content:space-between;align-items:center}
.logo{font-size:24px;font-weight:700;letter-spacing:1px}
.logo span,.hero-title{color:#9dbaff}
.nav-links{display:flex;gap:8px}
.nav-links a{padding:9px 14px;border-radius:14px;background:rgba(0,0,0,.55);color:#fff;text-decoration:none;font-size:14px}
.hero{min-height:680px;display:flex;align-items:center;justify-content:center;text-align:center;padding:70px 15px}
.avatar{
  width:120px;height:120px;margin:auto;border-radius:50%;
  background:linear-gradient(135deg,#8ba8d7,#182b45);
  display:flex;align-items:center;justify-content:center;font-size:54px;
  box-shadow:0 0 40px rgba(100,160,255,.25);border:3px solid rgba(255,255,255,.4)
}
h1{font-size:clamp(42px,7vw,75px);margin:22px 0 12px;letter-spacing:-2px}
.hero-text{max-width:720px;margin:auto;color:rgba(255,255,255,.78);font-size:18px;line-height:1.65}
.buttons{margin-top:28px;display:flex;justify-content:center;flex-wrap:wrap;gap:10px}
.btn{
  display:inline-flex;align-items:center;justify-content:center;padding:13px 18px;
  border-radius:16px;background:rgba(0,0,0,.72);color:#fff;text-decoration:none;
  border:1px solid rgba(255,255,255,.13);cursor:pointer;transition:.2s;font-size:15px
}
.btn:hover{transform:translateY(-2px)}
.btn-primary{background:linear-gradient(135deg,#3e68c9,#6c54c8)}
.btn-whatsapp{background:rgba(20,100,60,.78)}
section{padding:65px 0}
.title{text-align:center;font-size:34px;margin:0 0 30px}
.card{
  background:rgba(0,0,0,.48);border:1px solid rgba(255,255,255,.11);
  border-radius:24px;padding:28px;backdrop-filter:blur(12px);
  box-shadow:0 15px 45px rgba(0,0,0,.2)
}
.card p{color:rgba(255,255,255,.75);line-height:1.65}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.icon{font-size:34px}
.contact{text-align:center}
.contact .btn{margin:5px}
footer{text-align:center;padding:35px 10px;color:rgba(255,255,255,.55)}
#aiButton{
  position:fixed;right:18px;bottom:18px;width:64px;height:64px;border:0;border-radius:50%;
  background:linear-gradient(135deg,#557cff,#7555d8);color:#fff;font-size:27px;cursor:pointer;
  z-index:100;box-shadow:0 12px 40px rgba(70,90,220,.45)
}
#chat{
  position:fixed;right:18px;bottom:92px;width:390px;max-width:calc(100% - 28px);height:500px;
  background:#f9fbff;color:#172033;border-radius:24px;overflow:hidden;display:none;
  flex-direction:column;z-index:99;box-shadow:0 20px 70px rgba(0,0,0,.5)
}
.chat-header{
  background:linear-gradient(135deg,#4d70d8,#7158c8);color:#fff;padding:16px;
  display:flex;justify-content:space-between;align-items:center
}
.chat-header button{background:transparent;color:#fff;border:0;font-size:20px;cursor:pointer}
#messages{flex:1;padding:14px;overflow-y:auto}
.message{max-width:86%;padding:11px 13px;border-radius:15px;margin-bottom:9px;line-height:1.42;white-space:pre-wrap}
.bot{background:#e8efff}.user{margin-left:auto;background:#6178df;color:#fff}
.chat-input{padding:9px;display:flex;gap:7px;border-top:1px solid #ddd;background:#fff}
.chat-input input{flex:1;border:1px solid #ddd;border-radius:14px;padding:12px;outline:none;min-width:0}
.chat-input button{border:0;border-radius:14px;background:#6178df;color:#fff;padding:0 16px;cursor:pointer}
.snow{position:fixed;top:-20px;color:#fff;pointer-events:none;z-index:1;animation:fall linear infinite;opacity:.7}
@keyframes fall{0%{transform:translateY(-20px) translateX(0)}100%{transform:translateY(110vh) translateX(80px)}}
.mountains{position:fixed;bottom:0;left:0;width:100%;height:260px;z-index:0;background:linear-gradient(135deg,transparent 50%,#102b48 50%);opacity:.55}
@media(max-width:700px){
  .nav-links{display:none}.grid{grid-template-columns:1fr}
  .hero{min-height:620px;padding-top:55px}.avatar{width:105px;height:105px;font-size:46px}
  h1{font-size:43px}.hero-text{font-size:16px}
  section{padding:50px 0}.title{font-size:30px}
  #chat{right:10px;bottom:84px;width:calc(100% - 20px);height:min(455px,70vh);border-radius:20px}
  #aiButton{right:14px;bottom:14px;width:58px;height:58px}
}
</style>
</head>
<body>
<div class="mountains"></div>

<header>
<div class="container nav">
<div class="logo">SNIPER<span> AI</span></div>
<div class="nav-links">
<a href="#about">Обо мне</a>
<a href="#services">Услуги</a>
<a href="#contact">Контакты</a>
</div>
</div>
</header>

<main>
<section class="hero">
<div class="container">
<div class="avatar">👨‍💼</div>
<h1>SNIPER <span class="hero-title">AI</span></h1>
<p class="hero-text">AI-помощник, цифровые продукты и полезные решения. Здесь будут развиваться поиск товаров, AI-сервисы и партнёрские предложения.</p>
<div class="buttons">
<a class="btn btn-primary" href="#about">👤 Обо мне</a>
<a class="btn" href="#services">🚀 Мои направления</a>
<a class="btn" href="tel:+77474701201">📞 Позвонить</a>
<a class="btn btn-whatsapp" href="${WHATSAPP}" target="_blank" rel="noopener">💬 WhatsApp</a>
<a class="btn" href="mailto:${EMAIL}">✉️ Email</a>
<a class="btn" href="${TELEGRAM}" target="_blank" rel="noopener">✈️ Telegram</a>
</div>
</div>
</section>

<section id="about">
<div class="container">
<h2 class="title">Обо мне</h2>
<div class="card">
<p>Я развиваю современное направление бизнеса с использованием искусственного интеллекта.</p>
<p>Изучаю AI-технологии и создаю цифровые продукты, сайты, дизайн, контент и полезные решения.</p>
<p>Цель SNIPER AI — развивать собственные AI-сервисы и создавать практичные продукты для людей и бизнеса.</p>
</div>
</div>
</section>

<section id="services">
<div class="container">
<h2 class="title">Мои направления</h2>
<div class="grid">
<div class="card"><div class="icon">🤖</div><h3>AI-помощник</h3><p>Круглосуточный помощник для вопросов, информации и будущего поиска товаров.</p><button class="btn btn-primary" onclick="openAI()">Открыть AI</button></div>
<div class="card"><div class="icon">🛒</div><h3>Поиск товаров</h3><p>Запишите товар и бюджет. Архитектура подготовлена для подключения реальных магазинов и партнёрских ссылок.</p><button class="btn" onclick="openAIWithText('Найди пылесос до 100 000 ₸')">Пример поиска</button></div>
<div class="card"><div class="icon">📸</div><h3>Реставрация фото</h3><p>Восстановление старых фотографий, улучшение качества и раскрашивание.</p><a class="btn" href="mailto:${EMAIL}?subject=Реставрация фотографии">Заказать</a></div>
<div class="card"><div class="icon">🌎</div><h3>Переводы</h3><p>Перевод текстов на разные языки с использованием современных технологий.</p><a class="btn" href="mailto:${EMAIL}?subject=Перевод текста">Заказать</a></div>
<div class="card"><div class="icon">💡</div><h3>AI-сервисы</h3><p>В будущем здесь будут рекомендации AI-сервисов с партнёрскими ссылками.</p><button class="btn" onclick="openAIWithText('Расскажи про AI-сервисы')">Подробнее</button></div>
<div class="card"><div class="icon">🔗</div><h3>Партнёрские товары</h3><p>Подготовка к подключению AliExpress, Temu, Kaspi и других площадок после получения официальных affiliate-инструментов.</p><button class="btn" onclick="openAIWithText('Хочу подобрать товар')">Подобрать</button></div>
</div>
</div>
</section>

<section id="contact">
<div class="container contact">
<h2 class="title">Связаться со мной</h2>
<a class="btn btn-primary" href="tel:+77474701201">📞 +7 747 470-12-01</a>
<a class="btn btn-whatsapp" href="${WHATSAPP}" target="_blank" rel="noopener">💬 WhatsApp</a>
<a class="btn" href="mailto:${EMAIL}">✉️ ${EMAIL}</a>
<a class="btn" href="${TELEGRAM}" target="_blank" rel="noopener">✈️ @sniperssaai</a>
</div>
</section>
</main>

<footer>SNIPER AI © 2026</footer>

<button id="aiButton" onclick="openAI()" aria-label="Открыть AI">🤖</button>

<div id="chat" role="dialog" aria-label="SNIPER AI">
<div class="chat-header">
<div><strong>SNIPER AI</strong><br><small>AI-помощник</small></div>
<button onclick="closeAI()" aria-label="Закрыть">✕</button>
</div>
<div id="messages">
<div class="message bot">Здравствуйте! 👋<br>Я AI-помощник SNIPER AI.<br><br><strong>Чем могу помочь?</strong></div>
</div>
<div class="chat-input">
<input id="question" placeholder="Например: пылесос до 100 000 ₸" autocomplete="off"
onkeydown="if(event.key==='Enter')sendMessage()">
<button onclick="sendMessage()" aria-label="Отправить">➤</button>
</div>
</div>

<script>
function openAI(){document.getElementById("chat").style.display="flex";setTimeout(()=>document.getElementById("question").focus(),50)}
function closeAI(){document.getElementById("chat").style.display="none"}
function addMessage(text,type){
  const messages=document.getElementById("messages");
  const div=document.createElement("div");
  div.className="message "+type;
  div.textContent=text;
  messages.appendChild(div);
  messages.scrollTop=messages.scrollHeight;
}
function openAIWithText(text){
  openAI();
  document.getElementById("question").value=text;
  sendMessage();
}
async function sendMessage(){
  const input=document.getElementById("question");
  const text=input.value.trim();
  if(!text)return;
  addMessage(text,"user");
  input.value="";
  try{
    const response=await fetch("/api/chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:text})
    });
    if(!response.ok)throw new Error("HTTP "+response.status);
    const data=await response.json();
    addMessage(data.reply||"Не удалось получить ответ.","bot");
  }catch(error){
    addMessage("Не удалось получить ответ. Попробуйте ещё раз.","bot");
  }
}
for(let i=0;i<24;i++){
  const snow=document.createElement("div");
  snow.className="snow";
  snow.innerHTML="❄";
  snow.style.left=Math.random()*100+"%";
  snow.style.fontSize=(8+Math.random()*13)+"px";
  snow.style.animationDuration=(9+Math.random()*12)+"s";
  snow.style.animationDelay=Math.random()*10+"s";
  document.body.appendChild(snow);
}
</script>
</body>
</html>`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Lightweight event endpoint. For permanent private analytics, connect D1/KV.
    if (request.method === "POST" && url.pathname === "/api/event") {
      return json({ ok: true });
    }

    if (request.method === "POST" && url.pathname === "/api/chat") {
      try {
        const data = await request.json();
        const answer = aiReply(data.message);
        return json({ reply: answer });
      } catch (error) {
        return json({ reply: "Произошла ошибка. Попробуйте ещё раз." }, 400);
      }
    }

    return new Response(HTML, {
      headers: { "Content-Type": "text/html;charset=UTF-8" }
    });
  }
};
